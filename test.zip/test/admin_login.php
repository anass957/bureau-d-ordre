<?php
$mot_de_passe = $_POST['adminPassword'];
$mot_de_passe_correct = "1234"; 

if ($mot_de_passe === $mot_de_passe_correct) {
    header("Location: traitement.php");
    exit();
} else {
    echo "<p style='color:red; text-align:center;'>❌ كلمة المرور غير صحيحة</p>";
  
}
?>
