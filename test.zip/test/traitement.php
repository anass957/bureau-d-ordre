<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nom = $_POST['distributorName'];
    $adresse = $_POST['address'];
    $cin = $_POST['nationalId'];
    $bureau = $_POST['targetOffice'];
    $fichier = $_FILES['fileUpload'];

    $dossier = "demandes/";
    $chemin = $dossier . basename($fichier['name']);
    move_uploaded_file($fichier['tmp_name'], $chemin);

    $ligne = "$nom | $adresse | $cin | $bureau | $chemin\n";
    file_put_contents("donnees.txt", $ligne, FILE_APPEND);

    echo "Demande envoyée avec succès. <a href='user.html'>Retour</a>";
} else {
    if (!file_exists("donnees.txt")) exit("Aucune demande reçue.");

    foreach (file("donnees.txt", FILE_IGNORE_NEW_LINES) as $ligne) {
        list($nom, $adresse, $cin, $bureau, $chemin) = explode(" | ", $ligne);
        echo "$nom | $adresse | $cin | $bureau | <a href='$chemin'>Fichier</a><br>";
    }
}
?>
